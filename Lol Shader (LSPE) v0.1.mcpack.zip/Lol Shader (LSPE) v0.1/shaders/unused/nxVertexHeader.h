#version 430

#include "nvn.h"

out gl_PerVertex
{
	vec4 gl_Position;
};
